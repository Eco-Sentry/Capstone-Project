package ecosentry.admin.adminconsole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminconsoleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminconsoleApplication.class, args);
	}

}
