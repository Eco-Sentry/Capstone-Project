package ecosentry.authproxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthproxyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthproxyApplication.class, args);
	}

}
