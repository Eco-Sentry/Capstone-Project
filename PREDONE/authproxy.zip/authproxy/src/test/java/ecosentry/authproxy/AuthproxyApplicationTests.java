package ecosentry.authproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthproxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
