package ecosentry.node.databasemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabasemanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabasemanagerApplication.class, args);
	}

}
