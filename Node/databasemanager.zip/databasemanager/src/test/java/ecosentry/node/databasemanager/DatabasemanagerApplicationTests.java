package ecosentry.node.databasemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabasemanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
